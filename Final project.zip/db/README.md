# IntelliCourse – BootCamp Final Project

## 📖 Overview
**IntelliCourse** is an intelligent course information assistant.  
It allows students to:
- Search through university course catalogs (from uploaded PDFs).
- Retrieve course prerequisites and descriptions.
- Perform web searches when course information is not found locally.
- Get clear, AI-powered answers to their questions.

This project uses:
- **LangChain** for agent workflow
- **Chroma** as a vector database for storing PDF knowledge
- **HuggingFace Transformers** as the local LLM
- **Tavily API** for web search
- **FastAPI + Uvicorn** to run the backend server


## Setup Instructions

### 1. Clone the repository
```bash
git clone <your-repo-url>
cd "BootCamp Final Project"
```

BootCamp Final Project/
│── app/
│   ├── main.py
│   ├── agent.py
│   ├── rag.py
│── data/
│   ├── course1.pdf
│   ├── course2.pdf
│   ├── course3.pdf
│   ├── course4.pdf
│── requirements.txt
│── .env
│── README.md   
│── .venv/
