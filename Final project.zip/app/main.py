from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from pydantic import BaseModel
from app.agent import build_agent


app = FastAPI(title="Final API")

agent = build_agent()

class QueryRequest(BaseModel):
    query: str

class QueryResponse(BaseModel):
    answer: str

@app.post("/chat", response_model=QueryResponse)
async def chat(req: QueryRequest):
    state = {"query": req.query}
    final_state = agent.invoke(state)
    return QueryResponse(answer=final_state["answer"])



if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
