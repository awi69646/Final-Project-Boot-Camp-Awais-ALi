from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Optional: hardcode key (not recommended for production)
os.environ["TAVILY_API_KEY"] = os.getenv("TAVILY_API_KEY", "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")

print("TAVILY_API_KEY loaded:", os.getenv("TAVILY_API_KEY") is not None)

from langchain_community.llms import HuggingFacePipeline
from langchain_community.tools.tavily_search import TavilySearchResults
from transformers import pipeline
from app.rag import get_retriever  
from langgraph.graph import StateGraph, END

# ----------------------------
# Load LLM (local small model)
# ----------------------------
try:
    pipe = pipeline(
        "text-generation",
        model="distilgpt2",
        max_new_tokens=200,
        device=-1  # Force CPU, avoids GPU OOM
    )
    print(" Loaded distilgpt2")
except Exception as e:
    print(" Falling back to tiny model due to error:", e)
    pipe = pipeline(
        "text-generation",
        model="sshleifer/tiny-gpt2",
        max_new_tokens=200,
        device=-1
    )

llm = HuggingFacePipeline(pipeline=pipe)
# ----------------------------
# Tools
# ----------------------------
retriever = get_retriever()
web_search = TavilySearchResults()

# ----------------------------
# Agent state
# ----------------------------
class AgentState(dict):
    pass

# ----------------------------
# Router node
# ----------------------------
def router(state: AgentState):
    query = state["query"].lower()
    if "course" in query or "prerequisite" in query or "catalog" in query:
        return "course"
    return "web"

# ----------------------------
# Course retriever node
# ----------------------------
def course_node(state: AgentState):
    docs = retriever.get_relevant_documents(state["query"])
    state["context"] = "\n".join([d.page_content for d in docs[:3]]) or "No course info found."
    return state

# ----------------------------
# Web search node
# ----------------------------
def web_node(state: AgentState):
    results = web_search.run(state["query"])
    state["context"] = results or "No web results found."
    return state

# ----------------------------
# Generation node
# ----------------------------
def generate_node(state: AgentState):
    prompt = f"Question: {state['query']}\nContext: {state['context']}\nAnswer clearly:"
    result = llm(prompt)

    # HuggingFacePipeline returns list sometimes → make sure it's text
    if isinstance(result, list) and "generated_text" in result[0]:
        state["answer"] = result[0]["generated_text"]
    else:
        state["answer"] = str(result)
    return state

# ----------------------------
# Build agent graph
# ----------------------------
def build_agent():
    graph = StateGraph(AgentState)

    # Nodes
    graph.add_node("router", router)
    graph.add_node("course", course_node)
    graph.add_node("web", web_node)
    graph.add_node("generate", generate_node)

    # Edges
    graph.add_conditional_edges("router", router, {"course": "course", "web": "web"})
    graph.add_edge("course", "generate")
    graph.add_edge("web", "generate")
    graph.add_edge("generate", END)

    # Entry point
    graph.set_entry_point("router")

    return graph.compile()
