from dotenv import load_dotenv
load_dotenv()

import os
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings


# Load documents from all PDFs in /data
def load_documents():
    docs_dir = os.path.join(os.getcwd(), "data")
    pdf_files = [f for f in os.listdir(docs_dir) if f.endswith(".pdf")]

    documents = []
    for file in pdf_files:
        file_path = os.path.join(docs_dir, file)

        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            print(f" Skipping: {file} (missing or empty)")
            continue

        loader = PyPDFLoader(file_path)
        documents.extend(loader.load())
        print(f"Loaded: {file}")

    return documents


# Split into chunks
def split_documents(documents):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    return splitter.split_documents(documents)


# Create embeddings + store in Chroma
def create_vectorstore(docs):
    persist_dir = os.getenv("CHROMA_PERSIST_DIR", "db")
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )
    vectordb = Chroma.from_documents(
        docs,
        embeddings,
        persist_directory=persist_dir
    )
    vectordb.persist()
    print(f" Vectorstore saved in: {persist_dir}")
    return vectordb


# Retriever
def get_retriever():
    persist_dir = os.getenv("CHROMA_PERSIST_DIR", "db")
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )
    vectordb = Chroma(
        persist_directory=persist_dir,
        embedding_function=embeddings
    )
    return vectordb.as_retriever()


if __name__ == "__main__":
    print(" Loading and processing course catalog PDFs...")
    docs = load_documents()

    if not docs:
        print(" No valid PDFs found in /data. Please add PDFs first.")
    else:
        chunks = split_documents(docs)
        create_vectorstore(chunks)
        print(" All done!")
